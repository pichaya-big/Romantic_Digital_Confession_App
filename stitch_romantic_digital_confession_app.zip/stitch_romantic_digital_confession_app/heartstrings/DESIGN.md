---
name: Heartstrings
colors:
  surface: '#fdf9f3'
  surface-dim: '#dddad4'
  surface-bright: '#fdf9f3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f7f3ed'
  surface-container: '#f1ede7'
  surface-container-high: '#ebe8e2'
  surface-container-highest: '#e6e2dc'
  on-surface: '#1c1c18'
  on-surface-variant: '#5c3f40'
  inverse-surface: '#31302d'
  inverse-on-surface: '#f4f0ea'
  outline: '#906f70'
  outline-variant: '#e5bdbe'
  surface-tint: '#be0037'
  primary: '#b80035'
  on-primary: '#ffffff'
  primary-container: '#e11d48'
  on-primary-container: '#fffaf9'
  inverse-primary: '#ffb3b6'
  secondary: '#674bb5'
  on-secondary: '#ffffff'
  secondary-container: '#ab8ffe'
  on-secondary-container: '#3f1e8c'
  tertiary: '#a42f46'
  on-tertiary: '#ffffff'
  tertiary-container: '#c5485d'
  on-tertiary-container: '#fffaf9'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdada'
  primary-fixed-dim: '#ffb3b6'
  on-primary-fixed: '#40000c'
  on-primary-fixed-variant: '#920028'
  secondary-fixed: '#e8ddff'
  secondary-fixed-dim: '#cebdff'
  on-secondary-fixed: '#21005e'
  on-secondary-fixed-variant: '#4f319c'
  tertiary-fixed: '#ffdadc'
  tertiary-fixed-dim: '#ffb2b9'
  on-tertiary-fixed: '#400010'
  on-tertiary-fixed-variant: '#891933'
  background: '#fdf9f3'
  on-background: '#1c1c18'
  surface-variant: '#e6e2dc'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Nunito Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Nunito Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Nunito Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.5rem
  margin: 1.25rem
  margin-tablet: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system expresses intimate vulnerability, gentle affection, and poetic modern romance. Designed specifically for long-distance partners, secret crushes, and lifelong sweethearts sharing letters and dating confessions, the interface balances raw sentimental warmth with polished contemporary digital craftsmanship.

The visual direction centers on **Soft Ethereal Glassmorphism**:
- Translucent frosted surfaces reminiscent of sheer vellum stationery, allowing deep romantic gradients to subtly glow through.
- Smooth tactile contours and pill-shaped touch targets that feel gentle and inviting under the thumb.
- Micro-interactions infused with lightness—floating ambient particles, delicate glowing pulses, and heart-like springs on interaction.
- Mobile portrait-first orientation, optimized for late-night handheld writing and private, screen-held reading.

## Colors

The palette derives from sunset skies, dried roses, handwritten ink, and candlelight.

- **Primary (`#E11D48`)**: Deep berry rose used for primary actions, critical emotional highlights, and key affirmations. Communicates profound passion without the harshness of generic alert reds.
- **Secondary (`#A78BFA`)**: Dreamy twilight lavender, utilized for contemplative moments, secondary badges, audio playback indicators, and gentle gradients.
- **Tertiary (`#FB7185`)**: Radiant blush coral, used for floating micro-particles, active heart reactions, and playful toggles.
- **Neutral (`#FFFBF5`)**: Warm, buttery porcelain cream serving as the canvas backdrop, shielding the reader from the cold sterile glare of pure white.
- **Surface & Glass Tints**:
  - Frosted Vellum: `rgba(255, 251, 245, 0.72)` paired with `backdrop-filter: blur(16px)`.
  - Border Accents: `rgba(225, 29, 72, 0.15)` transitioning to `rgba(167, 139, 250, 0.20)` for iridescent rose-gold edges.
  - Text Primary: Rich cassis noir (`#3B0720`) to maintain AAA accessibility over blush and cream tones.

## Typography

The typography unites **Plus Jakarta Sans** for expressive, polished headings and UI anchors with **Nunito Sans** for warm, readable, intimate body prose.

- **Headlines & Titles**: Plus Jakarta Sans delivers structural elegance with soft curves that feel conversational yet refined. Titles utilize tighter tracking to convey closeness.
- **Body & Longform Letters**: Nunito Sans provides open apertures and rounded terminals, softening digital confessions and long romantic letters for effortless sustained reading.
- **Mobile Scale Adaptation**: Large display headlines scale gracefully down to 32px on portrait viewports, preventing awkward hyphenation while preserving romantic grandeur.

## Layout & Spacing

The layout is built mobile portrait-first, embracing focused single-column reading and card-based stacks that evoke sliding letters out of envelopes.

- **Grid Architecture**:
  - **Mobile (<768px)**: 4-column fluid layout with `1.25rem` outer canvas padding and `1rem` gutters. Maximizes screen real estate for thumb-accessible writing and reading.
  - **Tablet & Desktop (≥768px)**: Centered reading column (max width 640px) to preserve intimate, diary-like ergonomics even on wider screens.
- **Vertical Rhythm**: Generous paragraph spacing (`space-lg`) between letter stanzas, mimicking authentic poetic line breaks and allowing confessions breathing room.

## Elevation & Depth

Visual hierarchy eschews opaque dropshadows in favor of **Soft Translucent Layers & Tinted Diffused Glows**:

- **Frosted Tier 1 (Cards, Stanzas, Confession Sheets)**:
  - Background: `rgba(255, 251, 245, 0.75)` with `16px` backdrop-blur.
  - Border: 1px continuous hairline `rgba(251, 113, 133, 0.22)`.
  - Shadow: `0 8px 32px -4px rgba(225, 29, 72, 0.08), 0 2px 8px -2px rgba(167, 139, 250, 0.06)`.
- **Frosted Tier 2 (Floating Action Buttons, Menus, Modals)**:
  - Background: `rgba(255, 255, 255, 0.90)` with `24px` backdrop-blur.
  - Border: 1px `rgba(225, 29, 72, 0.35)`.
  - Shadow: `0 16px 48px -8px rgba(190, 24, 93, 0.16), 0 4px 12px -2px rgba(0, 0, 0, 0.04)`.
- **Underlying Atmosphere**: Radial background blobs in soft lavender (`#EDE9FE`) and warm blush (`#FCE7F3`) slowly breathe beneath the frosted glass plane.

## Shapes

The interface embraces **Pill-shaped (Level 3)** geometry:

- **Buttons & Chips**: Pure pill shapes (`border-radius: 9999px` or `1rem` base) to mimic smooth beach stones and tactile seals.
- **Cards & Sheet Envelopes**: Rounded corners at `1.5rem` (`rounded-lg`) up to `2rem` (`rounded-xl`), creating organic, envelope-like containers without severe corners.
- **Avatars & Reactions**: Circular frames with rose-gold gradient borders (`1.5px`), accentuating soft portrait imagery.

## Components

### Buttons
- **Primary ("Send Letter", "Reveal Confession")**: Pill-shaped, gradient fill from `#E11D48` to `#FB7185`. Text is pure white (`#FFFFFF`) with Plus Jakarta Sans bold. On press: subtle scale dampening (`scale(0.97)`), followed by a soft rose glow pulse.
- **Secondary ("Save Draft")**: Frosted glass background (`rgba(255, 251, 245, 0.6)`), 1.5px border in `#A78BFA`, and deep cassis text.

### Confession & Letter Cards
- Composed of Tier 1 frosted glass with delicate 1px rose gold edges.
- Header features an optional wax-seal badge or miniature stamp illustration.
- Subtle inner gradient vignette providing a stationery feel.

### Chips & Tags
- Height: 32px, pill-curved, filled with soft blush (`#FCE7F3`) or whisper lavender (`#EDE9FE`).
- Micro-labels set in `label-sm` with matching deep berry (`#BE185D`) or plum typography.

### Input Fields & Letter Editors
- Unbounded, distraction-free writing surface with light parchment background tint.
- Focus state softens the border with a gentle 3px outer glow of `#FB7185` at 30% opacity.
- Placeholder text in muted blush lavender (`#9C7786`).

### Checkboxes & Toggle Hearts
- Standard checkboxes are replaced with heart-shaped toggle switches.
- Inactive state: outlined heart in muted lavender.
- Active state: fills with `#E11D48` using an elastic bounce micro-animation, releasing 2–3 micro heart particles that float upwards and fade.

### Specialized Component: Audio Love Note Player
- Frosted capsule bar with an animated lavender/berry waveform.
- Scrub thumb represented as a small glowing rose-gold pearl.